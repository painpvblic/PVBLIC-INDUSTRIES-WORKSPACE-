export default async function handler(req, res) {
  if (req.method === 'GET') {
    return res.status(200).json({ ok: true, message: 'Backend PVBLIC aktif. Endpoint Gemini siap menerima POST.' });
  }

  if (req.method !== 'POST') {
    res.setHeader('Allow', 'GET, POST');
    return res.status(405).json({ error: 'Method not allowed. Gunakan POST untuk mengirim pesan.' });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'GEMINI_API_KEY belum diatur pada Environment Variables Vercel.' });
  }

  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
    const message = String(body.message || body.prompt || '').trim();
    if (!message) return res.status(400).json({ error: 'Pesan kosong.' });
    if (message.length > 20000) return res.status(413).json({ error: 'Pesan terlalu panjang. Batasi hingga 20.000 karakter.' });

    const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
    const upstream = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: 'Kamu adalah asisten AI di PVBLIC INDUSTRIES WORKSPACE. Jawab dengan jelas, membantu, dan sesuai bahasa yang digunakan pengguna.' }] },
        contents: [{ role: 'user', parts: [{ text: message }] }],
        generationConfig: { temperature: 0.7, maxOutputTokens: 2048 }
      })
    });

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const detail = data?.error?.message || `Google Gemini API merespons HTTP ${upstream.status}.`;
      return res.status(upstream.status >= 400 && upstream.status < 600 ? upstream.status : 502).json({ error: detail });
    }

    const reply = (data.candidates?.[0]?.content?.parts || []).map(part => part.text || '').join('\n').trim();
    if (!reply) return res.status(502).json({ error: 'Gemini tidak mengembalikan teks. Coba kirim pesan lagi.' });
    return res.status(200).json({ reply, model });
  } catch (error) {
    return res.status(500).json({ error: 'Terjadi kesalahan pada backend saat memproses permintaan.' });
  }
}
