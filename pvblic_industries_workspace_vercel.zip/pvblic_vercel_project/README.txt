PVBLIC INDUSTRIES WORKSPACE — VERCEL PROJECT

Files:
- index.html: workspace frontend
- api/chat.js: server-side Gemini API endpoint
- package.json: project metadata

IMPORTANT SETUP
1. In Vercel Project Settings > Environment Variables, set:
   GEMINI_API_KEY = your Google AI Studio Gemini API key
   Environment: Production (and Preview if you also want previews to work)
2. Optionally set GEMINI_MODEL = gemini-2.5-flash
3. Deploy this whole project folder as a new deployment/project. The api/chat.js file must be included at the project root in a folder named api.
4. After deploy, open /api/chat on the website. A JSON status message should appear.
5. Open the workspace and send a test message to Gemini.

Never put the API key into index.html or share it publicly.

If using Vercel Drop, upload the project folder (not just index.html). If the mobile browser only allows a single file upload, use a GitHub repository containing all files and import it into Vercel.
